package com.example.tutoriasuvg.presentation.funcionalidades_estudiantes

import androidx.lifecycle.ViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update

data class DetalleTutoria(
    val title: String,
    val date: String,
    val location: String,
    val time: String,
    val tutorName: String,
    val isVirtual: Boolean,
    val link: String? = null
)

class DetallesTutoriasViewModel : ViewModel() {

    private val _detalleTutoria = MutableStateFlow<DetalleTutoria?>(null)
    val detalleTutoria: StateFlow<DetalleTutoria?> = _detalleTutoria

    init {
        loadMockDetalleTutoria()
    }

    private fun loadMockDetalleTutoria() {
        _detalleTutoria.update {
            DetalleTutoria(
                title = "Física 3",
                date = "19/09/2024",
                location = "Virtual",
                time = "15:00 hrs - 16:00 hrs",
                tutorName = "Nombre del Tutor",
                isVirtual = true,
                link = "Link de Zoom"
            )
        }
    }

    fun cargarDetalleTutoria(
        title: String,
        date: String,
        location: String,
        time: String,
        tutorName: String,
        isVirtual: Boolean,
        link: String? = null
    ) {
        _detalleTutoria.update {
            DetalleTutoria(title, date, location, time, tutorName, isVirtual, link)
        }
    }
}
