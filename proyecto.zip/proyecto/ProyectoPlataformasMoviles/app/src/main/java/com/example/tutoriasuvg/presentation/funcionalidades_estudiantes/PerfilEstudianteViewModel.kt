package com.example.tutoriasuvg.presentation.funcionalidades_estudiantes

import androidx.lifecycle.ViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update

data class PerfilEstudiante(
    val nombre: String,
    val carnet: String,
    val anioCurso: String
)

class PerfilEstudianteViewModel : ViewModel() {

    private val _perfil = MutableStateFlow(
        PerfilEstudiante(
            nombre = "Nombre del Estudiante",
            carnet = "Carnet del Estudiante",
            anioCurso = "Año que Cursa el Estudiante"
        )
    )
    val perfil: StateFlow<PerfilEstudiante> = _perfil

    fun actualizarPerfil(nombre: String, carnet: String, anioCurso: String) {
        _perfil.update {
            PerfilEstudiante(nombre, carnet, anioCurso)
        }
    }
}
