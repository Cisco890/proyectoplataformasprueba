ppackage com.example.tutoriasuvg.presentation.funcionalidades_estudiantes

import androidx.lifecycle.ViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update

data class SolicitudTutoria(
    val curso: String,
    val diasPreferencia: Set<String>,
    val jornadaPreferencia: String
)

class SolicitudTutoriaViewModel : ViewModel() {

    private val _solicitudes = MutableStateFlow<List<SolicitudTutoria>>(emptyList())
    val solicitudes: StateFlow<List<SolicitudTutoria>> = _solicitudes

    init {
        loadMockSolicitudes()
    }

    private fun loadMockSolicitudes() {
        _solicitudes.update {
            listOf(
                SolicitudTutoria(
                    curso = "Ecuaciones Diferenciales I",
                    diasPreferencia = setOf("Martes", "Jueves"),
                    jornadaPreferencia = "Vespertina"
                ),
                SolicitudTutoria(
                    curso = "Física 3",
                    diasPreferencia = setOf("Lunes", "Viernes"),
                    jornadaPreferencia = "Matutina"
                )
            )
        }
    }

    fun agregarSolicitud(curso: String, diasPreferencia: Set<String>, jornadaPreferencia: String) {
        _solicitudes.update { solicitudes ->
            solicitudes + SolicitudTutoria(curso, diasPreferencia, jornadaPreferencia)
        }
    }
}
