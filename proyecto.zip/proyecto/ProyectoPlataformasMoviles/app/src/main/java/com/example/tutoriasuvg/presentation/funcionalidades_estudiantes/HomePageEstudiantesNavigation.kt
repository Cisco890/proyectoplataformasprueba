package com.example.tutoriasuvg.presentation.funcionalidades_estudiantes

import androidx.compose.runtime.Composable
import androidx.navigation.NavController

@Composable
fun HomePageEstudiantesNavigation(navController: NavController) {
    HomePageEstudiantes(
        onVerProgresosClick = {
            navController.navigate(VerProgresosEstudianteDestination().route)
        },
        onSolicitarTutoriaClick = {
            navController.navigate(SolicitarTutoriaDestination().route)
        }
    )
}
