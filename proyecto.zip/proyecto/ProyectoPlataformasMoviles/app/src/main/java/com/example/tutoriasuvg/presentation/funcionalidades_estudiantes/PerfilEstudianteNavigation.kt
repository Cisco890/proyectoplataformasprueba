package com.example.tutoriasuvg.presentation.funcionalidades_estudiantes

import androidx.compose.runtime.Composable
import androidx.navigation.NavController

@Composable
fun PerfilEstudianteNavigation(
    navController: NavController,
    nombre: String,
    carnet: String,
    anioCurso: String
) {
    PerfilEstudianteScreen(
        onBackClick = { navController.popBackStack() },
        nombre = nombre,
        carnet = carnet,
        anioCurso = anioCurso
    )
}
