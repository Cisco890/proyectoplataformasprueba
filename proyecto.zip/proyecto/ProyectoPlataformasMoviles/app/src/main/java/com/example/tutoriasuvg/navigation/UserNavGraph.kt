package com.example.tutoriasuvg.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.navArgument
import com.example.tutoriasuvg.presentation.funcionalidades_admin.*
import com.example.tutoriasuvg.presentation.funcionalidades_estudiantes.*
import com.example.tutoriasuvg.presentation.funcionalidades_tutores.*
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

@Composable
fun UserNavGraph(navController: NavHostController) {
    NavHost(
        navController = navController,
        startDestination = HomePageAdminDestination().route
    ) {
        // Pantalla de inicio para tutores
        composable("homePageTutores") {
            HomePageTutoresNavigation(navController)
        }

        // Detalles de la tutoría para tutores
        composable(
            route = "detalles_tutoria/{tutoriaJson}",
            arguments = listOf(navArgument("tutoriaJson") {
                type = NavType.StringType
            })
        ) { backStackEntry ->
            val tutoriaJson = backStackEntry.arguments?.getString("tutoriaJson")
            val tutoria = tutoriaJson?.let { Json.decodeFromString<Tutoria>(it) }
            if (tutoria != null) {
                DetallesTutoriaNavigation(navController, tutoriaJson)
            }
        }

        // Progreso de horas de beca para tutores
        composable("progresoHorasBeca") {
            ProgresoHorasBecaNavigation(navController)
        }

        // Pantalla de inicio para administradores
        composable(HomePageAdminDestination().route) {
            HomePageAdminNavigation(navController)
        }

        // Ver progresos para administradores
        composable(VerProgresosDestination().route) {
            VerProgresosNavigation(navController)
        }

        // Notificaciones para administradores
        composable(NotificacionesDestination().route) {
            NotificacionesNavigation(navController)
        }

        // Agregamos las rutas para las funcionalidades del estudiante

        // Pantalla de inicio para estudiantes
        composable("homePageEstudiantes") {
            HomePageEstudiantesNavigation(navController)
        }

        // Detalles de la tutoría para estudiantes
        composable(
            route = "detalles_tutoria_estudiante/{title}/{date}/{location}/{time}/{tutorName}/{isVirtual}/{link}",
            arguments = listOf(
                navArgument("title") { type = NavType.StringType },
                navArgument("date") { type = NavType.StringType },
                navArgument("location") { type = NavType.StringType },
                navArgument("time") { type = NavType.StringType },
                navArgument("tutorName") { type = NavType.StringType },
                navArgument("isVirtual") { type = NavType.BoolType },
                navArgument("link") { type = NavType.StringType; defaultValue = null }
            )
        ) { backStackEntry ->
            val title = backStackEntry.arguments?.getString("title") ?: ""
            val date = backStackEntry.arguments?.getString("date") ?: ""
            val location = backStackEntry.arguments?.getString("location") ?: ""
            val time = backStackEntry.arguments?.getString("time") ?: ""
            val tutorName = backStackEntry.arguments?.getString("tutorName") ?: ""
            val isVirtual = backStackEntry.arguments?.getBoolean("isVirtual") ?: false
            val link = backStackEntry.arguments?.getString("link")

            DetallesTutoriasNavigation(
                navController = navController,
                title = title,
                date = date,
                location = location,
                time = time,
                tutorName = tutorName,
                isVirtual = isVirtual,
                link = link
            )
        }

        // Solicitud de tutoría para estudiantes
        composable("solicitud_tutoria") {
            SolicitudTutoriaNavigation(navController)
        }

        // Perfil del estudiante
        composable(
            route = "perfil_estudiante/{nombre}/{carnet}/{anioCurso}",
            arguments = listOf(
                navArgument("nombre") { type = NavType.StringType },
                navArgument("carnet") { type = NavType.StringType },
                navArgument("anioCurso") { type = NavType.StringType }
            )
        ) { backStackEntry ->
            val nombre = backStackEntry.arguments?.getString("nombre") ?: ""
            val carnet = backStackEntry.arguments?.getString("carnet") ?: ""
            val anioCurso = backStackEntry.arguments?.getString("anioCurso") ?: ""

            PerfilEstudianteNavigation(
                navController = navController,
                nombre = nombre,
                carnet = carnet,
                anioCurso = anioCurso
            )
        }
    }
}



