package com.example.tutoriasuvg.presentation.funcionalidades_estudiantes

import androidx.compose.runtime.Composable
import androidx.navigation.NavController

@Composable
fun DetallesTutoriasNavigation(
    navController: NavController,
    title: String,
    date: String,
    location: String,
    time: String,
    tutorName: String,
    isVirtual: Boolean,
    link: String? = null
) {
    DetallesTutoriasScreen(
        onBackClick = { navController.popBackStack() },
        title = title,
        date = date,
        location = location,
        time = time,
        tutorName = tutorName,
        isVirtual = isVirtual,
        link = link
    )
}
